import {combineReducers} from 'redux';
import {product} from '../components/product/reducer';

const allReducers = combineReducers({
     product
});


export default allReducers;